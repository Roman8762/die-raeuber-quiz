# Die Räuber Quiz

Interaktives Lernlabyrinth zu Friedrich Schillers *Die Räuber* für die Maturavorbereitung.

## Projektstruktur

- `index.html`: spielbare Webversion
- `materialien/code-die-raeuber.odt`: ursprüngliche Textgrundlage aus dem ZIP-Archiv

## Lokal starten

Die Seite ist statisch und braucht keinen Build-Prozess. Du kannst sie direkt im Browser öffnen:

1. `index.html` doppelklicken
2. oder einen kleinen lokalen Server starten, zum Beispiel mit `python3 -m http.server`

## Für GitHub vorbereiten

1. Repository auf GitHub anlegen
2. dieses Verzeichnis als Git-Repository initialisieren
3. Dateien committen und nach GitHub pushen
4. optional GitHub Pages aktivieren, damit das Quiz direkt online läuft

## Bereits behobene Punkte

- Die HTML-Datei wurde korrekt als `index.html` abgelegt
- Die Spiel-Logik blockiert Mehrfachklicks während des Übergangs zur nächsten Frage
- Die Audio-Funktionen sind robuster, falls WebAudio im Browser nicht verfügbar ist
- Das Projekt hat jetzt eine klare, GitHub-taugliche Struktur
